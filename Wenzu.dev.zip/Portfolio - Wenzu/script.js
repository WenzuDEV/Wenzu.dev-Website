window.addEventListener('scroll', () => {
  const navbar = document.querySelector('.navbar');
  if (window.scrollY > 30) {
    navbar.style.background = 'rgba(0,0,0,0.85)';
  } else {
    navbar.style.background = 'rgba(0,0,0,0.6)';
  }
});